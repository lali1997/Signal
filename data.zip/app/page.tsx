'use client'

import { useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import HtmlOverlay from '@/components/HtmlOverlay'

const Scene = dynamic(() => import('@/components/Scene'), { ssr: false })

export default function Home() {
  const [scrollT, setScrollT] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollable = document.documentElement.scrollHeight - window.innerHeight
      setScrollT(Math.min(1, Math.max(0, window.scrollY / scrollable)))
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div style={{ height: '500vh', position: 'relative' }}>
      <div style={{ position: 'sticky', top: 0, height: '100vh', overflow: 'hidden' }}>
        <Scene scrollT={scrollT} />
        <HtmlOverlay scrollT={scrollT} />
      </div>
    </div>
  )
}
