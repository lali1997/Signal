import { readFileSync } from 'fs'
import { join } from 'path'
import { computeAll } from '@/lib/calculations'
import DashboardClient from '@/components/dashboard/DashboardClient'

export default function DashboardPage() {
  const raw = JSON.parse(readFileSync(join(process.cwd(), 'data/entries.json'), 'utf-8'))
  const entries = raw.entries.map((e: any) => ({ date: e.date, weight: e.weight, steps: e.steps }))
  const meta = {
    name: raw.meta.name,
    goal_weight: raw.meta.goal_weight,
    start_date: raw.meta.start_date,
    log_gap_warn: raw.meta.log_gap_warn ?? 3,
  }
  const sound = raw.meta.sound === 1
  const today = new Date().toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' })
  const data = computeAll(entries, meta, today)
  return <DashboardClient data={data} sound={sound} />
}
